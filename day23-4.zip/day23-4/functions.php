<?php

wp_enqueue_style('style-lamia',get_stylesheet_uri());
wp_enqueue_style('style-boot',get_template_directory_uri().'/assets/css/bootstrap.min.css');

wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support('custom-logo');
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );

register_sidebar(array(
    'name'=>'Banner',
    'id'=>'banner',
    'before_widget'=>'',
    'after_widget'=>''
));
register_sidebar(array(
    'name'=>'side Images',
    'id'=>'sideimg',
    'before_widget'=>'',
    'after_widget'=>''
));
register_sidebar(array(
    'name'=>'side Video',
    'id'=>'sidevideo',
    'before_widget'=>'',
    'after_widget'=>''
));
register_sidebar(array(
    'name'=>'hero list',
    'id'=>'herolist',
    'before_widget'=>'',
    'after_widget'=>''
));
register_sidebar(array(
    'name'=>'Footer Main',
    'id'=>'footertop',
    'before_widget'=>'',
    'after_widget'=>''
));
register_sidebar(array(
    'name'=>'Footer bottom',
    'id'=>'footerbottom',
    'before_widget'=>'',
    'after_widget'=>''
));
register_nav_menus(array(
    'Main_Menu'=>'primary',
    'FM'=>'Footer'
) );